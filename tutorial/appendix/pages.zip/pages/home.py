# Import packages
import dash
import dash_bootstrap_components as dbc
from dash import html

# Register page
dash.register_page(__name__, path="/")

# Page Layout
layout = dbc.Container(
    children=[
        html.H1(children="This is our Home page"),
        html.Div(children="""This is our Home page content."""),
    ]
)
