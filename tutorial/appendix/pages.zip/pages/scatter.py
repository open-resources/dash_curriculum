# Import packages
import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
import plotly.express as px

# Register page
dash.register_page(__name__)

# Data
df = px.data.gapminder()
df_2007 = df[df.year == 2007]
continents = df["continent"].unique()

# Tabs
tabs = [
    dbc.Tab(
        dbc.Card(
            [
                dbc.CardBody(
                    [
                        html.H5(
                            "Analysis on Life Expectation / GDP per Capita in 2007"
                        ),
                        dcc.Graph(
                            figure=px.scatter(
                                df_2007,
                                x="gdpPercap",
                                y="lifeExp",
                                color="continent",
                                size="pop",
                                size_max=60,
                            )
                        ),
                    ]
                )
            ]
        ),
        label="World",
        activeLabelClassName="bg-light",
    )
]

for continent in continents:
    tabs.append(
        dbc.Tab(
            dbc.Card(
                [
                    dbc.CardBody(
                        [
                            html.H5(
                                "Analysis on Life Expectation / GDP per Capita in 2007 for {}".format(
                                    continent
                                )
                            ),
                            dcc.Graph(
                                figure=px.scatter(
                                    df_2007[df_2007["continent"] == continent],
                                    x="gdpPercap",
                                    y="lifeExp",
                                    color="country",
                                    size="pop",
                                    size_max=60,
                                )
                            ),
                        ]
                    )
                ]
            ),
            label=continent,
            activeLabelClassName="bg-light",
        )
    )

# Page Layout
layout = html.Div([dbc.Container([dbc.Tabs(tabs)])])
