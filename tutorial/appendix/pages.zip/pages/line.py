# Import packages
import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px

# Register page
dash.register_page(__name__)

# Data
df = px.data.stocks()
df["date"] = pd.to_datetime(df["date"], format="%Y-%m-%d")

# Figure
fig = px.line(
    df, x="date", y=["AAPL"], template="plotly_white", title="My Plotly Graph"
)

# Dropdown
dropdown = dcc.Dropdown(options=["AAPL", "GOOG", "MSFT"], value="AAPL")

# Date Picker
date_range = dcc.DatePickerRange(
    start_date_placeholder_text="start date",
    end_date_placeholder_text="end date",
    min_date_allowed=df.date.min(),
    max_date_allowed=df.date.max(),
    display_format="DD-MMM-YYYY",
    first_day_of_week=1,
)

# Checklist
checklist = dbc.Checklist(
    options=[{"label": "Dark theme", "value": 1}],
    value=[],
    switch=True,
)

# Radio items
radio_items = dbc.RadioItems(
    options=[
        {"label": "Red", "value": 0},
        {"label": "Green", "value": 1},
        {"label": "Blue", "value": 2},
    ],
    value=2,
    inline=True,
)

# Card content
card_content = [
    dbc.CardBody(
        [
            html.H5("My Control Panel"),
            html.P(
                "1) Select an option of the dropdown",
            ),
            dropdown,
            html.Br(),
            html.P(
                "2) Pick a date range from the form",
            ),
            date_range,
            html.Br(),
            html.Hr(),
            html.H6("Optional input"),
            html.P(
                "3) Enable dark theme of your graph",
            ),
            checklist,
            html.Br(),
            html.P(
                "4) Change the color of the graphs line",
            ),
            radio_items,
        ]
    ),
]

# Page Layout
layout = html.Div(
    [
        dbc.Container(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Row(dbc.Card(card_content, color="light")),
                            ],
                            width=4,
                        ),
                        dbc.Col(
                            dbc.Card(
                                dcc.Graph(id="figure1", figure=fig), color="light",
                            ),
                            width=8,
                        ),
                    ]
                ),
            ],
        ),
    ]
)
