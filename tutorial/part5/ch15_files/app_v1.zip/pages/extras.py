import dash
from dash import html, dcc

dash.register_page(__name__)

layout = html.Div(children=[
    html.H1(children='This is our Extras page'),

    html.Div(children='''
        This is our Extras page content.
    '''),
])