import dash
from dash import html, callback, Input, Output
import dash_bootstrap_components as dbc
from dash_labs import print_registry
#import subprocess as sp

dash.register_page(__name__, order='2')

layout = dbc.Container(
    [
    dbc.Row([html.H1(children='Extras')]),
    dbc.Row([html.H3(children='Visualising the App Registry')]),
    dbc.Row(
        [dbc.Col(dbc.Button(children="Print Registry to Console", id='print-reg'), width = 10)]
         ),
    dbc.Row(
        [html.P(id='res-')]
         )
    ],
    fluid=True
)

@callback(
    Output(component_id='res-', component_property='children'),
    Input(component_id='print-reg', component_property='n_clicks')
)
def print_reg(n):
    if n is not None:
        print_registry(exclude="layout")
        # r_ = str(sp.check_output(print_registry()))
        return 'Check the console'
